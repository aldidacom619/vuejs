</main>
<script src="../recursos/vue.js"></script>
<script src="../recursos/axios.min.js" ></script>
<script src="../recursos/sweetalert.min.js"></script>
<script src="../recursos/clipboard.min.js"></script>
<script src="../js/app.js"></script>
<script>
    new ClipboardJS('.copiar');
</script>
</body>
</html>