<?php
	header("location:login");
?>